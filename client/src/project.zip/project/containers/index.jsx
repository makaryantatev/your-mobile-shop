import { MyHomePage } from "./home";

export {MyHomePage}