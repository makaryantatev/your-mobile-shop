import { useState } from "react";
import productApi from "../../api/api/servicesApi";
import { H1, Input, MainDiv } from "../signIn/style"

export const Reviews = () => {
    const [formData, setFormData] = useState({})

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    // const addReview = async () => {
    //     const token = localStorage.getItem('token');
    //     console.log(token);
    //     console.log(1); 
    
    //     try {
    //         const res = await productApi.addReview(token, { desc: formData.desc });
    //         console.log(res.data); 
    //     } catch (error) {
    //         console.error("Error adding review");
    //     }
    // };

    const addReview = async () => {
        const token = localStorage.getItem('token');
        
        if (!token) {
            console.error("No authentication token found");
            return;
        }
    
        try {
            const res = await productApi.addReview(token, {
                description: formData.description, // Matches backend field
                number: formData.number // Matches backend field
            });
    
            console.log("Review added successfully:", res.data);
        } catch (error) {
            console.error("Error adding review:", error.response?.data || error.message);
        }
    };
    
    
    return(
        <>
            <div style={{height: "auto",padding: "30px" }}>
                <H1> Reviews </H1>
                <input type="text" placeholder="Reviews..." name="description" onChange={handleChange}/>
                <input type="number" placeholder="Rate 0 to 5" name="number" onChange={handleChange}/>
                <br />
                <button onClick={addReview}> send </button>
            </div>
        </>
    )
}
