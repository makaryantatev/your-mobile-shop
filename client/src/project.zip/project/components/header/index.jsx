import React from "react";
import { Navbar } from "./navbar";

export let MyHeader = () => {
    return(
        <>
            <Navbar/>
        </>
    )
} 